# MovieBook - Online Movie Ticket Booking System (Java)

A full-stack movie ticket booking web application built with **Java 17, Spring Boot, SQLite** and a vanilla **HTML5 / CSS3 / JavaScript** frontend.

This is the Java version of the project. The frontend, the database and every API route are the same as the earlier Flask version, so the website behaves identically.

## Features
- Browse active movies, pick a show (date, theatre, language, time) and choose seats on a 20-seat map (S1-S20)
- Atomic booking transaction that prevents double booking, and blocks shows that have already started
- E-ticket with booking ID, seats and barcode (printable)
- Booking history on the device, full or seat-level cancellation with automatic amount recalculation
- Password-protected admin portal: dashboard, movies (with poster upload), theatres, shows, bookings and revenue

## Tech stack
| Layer | Technology |
|---|---|
| Backend | Java 17, Spring Boot 3.3 (Spring MVC), plain JDBC |
| Database | SQLite (sqlite-jdbc) with WAL mode and IMMEDIATE transactions |
| Frontend | HTML5, CSS3, JavaScript (single-page customer site) |
| Build | Maven |
| Deployment | Docker on Render (also runs with `java -jar`) |

## Run locally
Requirements: JDK 17 or newer and Maven 3.8 or newer.

```bash
mvn spring-boot:run
```

or build a runnable jar:

```bash
mvn clean package
java -jar target/moviebook.jar
```

Open http://localhost:5000 (customer site) and http://localhost:5000/admin (admin portal).

Default admin password: `admin123`.

## Environment variables
| Variable | Purpose | Default |
|---|---|---|
| `PORT` | HTTP port | 5000 |
| `ADMIN_PASSWORD` | Admin login password | admin123 |
| `COOKIE_SECURE` | Set to `1` to mark the session cookie Secure (use on HTTPS) | 0 |
| `DATABASE_PATH` | Location of the SQLite file | `./movie_booking.db` |
| `APP_UTC_OFFSET_MINUTES` | Time zone offset used for "show started" checks | 330 (IST) |

## Project structure
```text
moviebook-java/
├── pom.xml
├── Dockerfile / Procfile / render.yaml
├── movie_booking.db                  SQLite database
├── static/                           CSS, JS and images (served at /static/...)
│   ├── style.css  script.js  admin.js
│   └── images/posters/               uploaded posters
└── src/main/
    ├── java/com/moviebook/
    │   ├── MovieBookApplication.java   entry point
    │   ├── AppSettings.java            environment configuration
    │   ├── Config.java                 static files, cookie settings, admin guard
    │   ├── Db.java                     SQLite connection and query helpers
    │   ├── Schema.java                 table creation, migrations, sample data
    │   ├── Util.java                   parsing, poster paths, show-time logic
    │   ├── PageController.java         pages, admin login / logout, health check
    │   ├── PublicController.java       customer API (movies, shows, seats, booking, cancel)
    │   ├── AdminController.java        admin API (movies, theatres, shows, bookings, revenue)
    │   └── ApiExceptionHandler.java    JSON error responses
    └── resources/
        ├── application.properties
        └── templates/                  index.html, admin.html, admin_login.html
```

## Deploy on Render
Push the folder to GitHub, create a new **Web Service** on Render and choose the **Docker** runtime (the included `render.yaml` and `Dockerfile` are used). Set `ADMIN_PASSWORD` in the environment settings.

Note: on Render's free plan the file system is not persistent, so bookings made on the live site can be lost when the service restarts or redeploys.
