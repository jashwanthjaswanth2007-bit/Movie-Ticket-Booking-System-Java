package com.moviebook;

import org.sqlite.SQLiteConfig;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Small JDBC helper around SQLite. Every connection uses foreign keys, WAL mode,
 * a 15 second busy timeout and IMMEDIATE transactions, so a booking transaction
 * takes the write lock as soon as it starts (prevents double booking).
 */
@Component
public class Db {

    private final String url;

    public Db(AppSettings settings) {
        this.url = "jdbc:sqlite:" + settings.databasePath;
    }

    public Connection open() throws SQLException {
        try {
            return DriverManager.getConnection(url, config(true).toProperties());
        } catch (SQLException walNotSupported) {
            return DriverManager.getConnection(url, config(false).toProperties());
        }
    }

    private static SQLiteConfig config(boolean wal) {
        SQLiteConfig config = new SQLiteConfig();
        config.enforceForeignKeys(true);
        config.setBusyTimeout(15000);
        config.setTransactionMode(SQLiteConfig.TransactionMode.IMMEDIATE);
        if (wal) {
            config.setJournalMode(SQLiteConfig.JournalMode.WAL);
        }
        return config;
    }

    // ---------- query helpers ----------

    public static List<Map<String, Object>> all(Connection c, String sql, Object... params) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, params);
            try (ResultSet rs = ps.executeQuery()) {
                ResultSetMetaData meta = rs.getMetaData();
                int columns = meta.getColumnCount();
                List<Map<String, Object>> rows = new ArrayList<>();
                while (rs.next()) {
                    Map<String, Object> row = new LinkedHashMap<>();
                    for (int i = 1; i <= columns; i++) {
                        row.put(meta.getColumnLabel(i), rs.getObject(i));
                    }
                    rows.add(row);
                }
                return rows;
            }
        }
    }

    public static Map<String, Object> one(Connection c, String sql, Object... params) throws SQLException {
        List<Map<String, Object>> rows = all(c, sql, params);
        return rows.isEmpty() ? null : rows.get(0);
    }

    /** Returns the first column of the first row as a number (0 when there is no row). */
    public static long count(Connection c, String sql, Object... params) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, params);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getLong(1) : 0L;
            }
        }
    }

    public static int run(Connection c, String sql, Object... params) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, params);
            return ps.executeUpdate();
        }
    }

    /** Runs an INSERT and returns the new row id. */
    public static long insert(Connection c, String sql, Object... params) throws SQLException {
        run(c, sql, params);
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT last_insert_rowid()")) {
            return rs.next() ? rs.getLong(1) : 0L;
        }
    }

    private static void bind(PreparedStatement ps, Object[] params) throws SQLException {
        for (int i = 0; i < params.length; i++) {
            ps.setObject(i + 1, params[i]);
        }
    }
}
