package com.moviebook;

import jakarta.servlet.ServletContext;
import jakarta.servlet.SessionCookieConfig;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.boot.web.servlet.ServletContextInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.nio.charset.StandardCharsets;

/** Static file serving, session cookie settings and the admin-area guard. */
@Configuration
public class Config implements WebMvcConfigurer {

    public static final String ADMIN_SESSION_KEY = "admin_authenticated";

    private final AppSettings settings;

    public Config(AppSettings settings) {
        this.settings = settings;
    }

    /** Serves /static/** from the static folder on disk, so uploaded posters appear immediately. */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        String location = settings.staticDir.toUri().toString();
        if (!location.endsWith("/")) {
            location = location + "/";
        }
        registry.addResourceHandler("/static/**").addResourceLocations(location);
    }

    @Bean
    public ServletContextInitializer sessionCookieSettings() {
        return (ServletContext context) -> {
            SessionCookieConfig cookie = context.getSessionCookieConfig();
            cookie.setHttpOnly(true);
            cookie.setSecure(settings.cookieSecure);
        };
    }

    /** Every /admin page and /api/admin/* call needs a logged-in admin session. */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new AdminGuard())
                .addPathPatterns("/admin", "/admin/**", "/api/admin/**")
                .excludePathPatterns("/admin/login", "/admin/logout");
    }

    public static boolean isAdmin(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        return session != null && Boolean.TRUE.equals(session.getAttribute(ADMIN_SESSION_KEY));
    }

    static class AdminGuard implements HandlerInterceptor {
        @Override
        public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
                throws Exception {
            if (isAdmin(request)) {
                return true;
            }
            if (request.getRequestURI().startsWith("/api/admin/")) {
                response.setStatus(401);
                response.setContentType("application/json");
                response.setCharacterEncoding(StandardCharsets.UTF_8.name());
                response.getWriter().write("{\"success\":false,\"message\":\"Admin authentication required.\"}");
            } else {
                response.sendRedirect("/admin/login");
            }
            return false;
        }
    }
}
