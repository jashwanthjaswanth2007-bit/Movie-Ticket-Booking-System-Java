package com.moviebook;

import org.springframework.stereotype.Component;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Set;

/** Configuration read from environment variables (same names as the Flask version). */
@Component
public class AppSettings {

    public static final int TOTAL_SEATS = 20;
    public static final Set<String> PAYMENT_METHODS = Set.of("UPI", "Credit Card", "Debit Card");
    public static final Set<String> IMAGE_EXTENSIONS = Set.of("png", "jpg", "jpeg", "webp");

    public final Path baseDir;
    public final Path staticDir;
    public final Path posterDir;
    public final String databasePath;
    public final String adminPassword;
    public final boolean cookieSecure;
    public final int utcOffsetMinutes;

    public AppSettings() {
        baseDir = Paths.get(env("APP_BASE_DIR", System.getProperty("user.dir"))).toAbsolutePath();
        staticDir = baseDir.resolve("static");
        posterDir = staticDir.resolve("images").resolve("posters");
        databasePath = env("DATABASE_PATH", baseDir.resolve("movie_booking.db").toString());
        adminPassword = env("ADMIN_PASSWORD", "admin123");
        cookieSecure = "1".equals(env("COOKIE_SECURE", "0"));
        utcOffsetMinutes = Integer.parseInt(env("APP_UTC_OFFSET_MINUTES", "330"));
    }

    private static String env(String key, String fallback) {
        String value = System.getenv(key);
        return (value == null || value.isBlank()) ? fallback : value;
    }
}
