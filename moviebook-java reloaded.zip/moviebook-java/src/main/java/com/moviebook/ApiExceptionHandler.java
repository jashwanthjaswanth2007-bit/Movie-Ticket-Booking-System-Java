package com.moviebook;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import java.sql.SQLException;
import java.util.Map;

@RestControllerAdvice
public class ApiExceptionHandler {

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<Map<String, Object>> tooLarge(MaxUploadSizeExceededException e) {
        return ResponseEntity.status(413).body(Util.map("error", "Uploaded file is too large (max 5MB)."));
    }

    @ExceptionHandler(SQLException.class)
    public ResponseEntity<Map<String, Object>> database(SQLException e) {
        return Util.fail(500, "Database error. Please try again.");
    }
}
