package com.moviebook;

import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Creates the tables, upgrades older databases and seeds sample data on start-up. */
@Component
public class Schema {

    private final Db db;
    private final AppSettings settings;

    public Schema(Db db, AppSettings settings) {
        this.db = db;
        this.settings = settings;
    }

    @PostConstruct
    public void initialize() throws SQLException, IOException {
        Files.createDirectories(settings.posterDir);

        try (Connection c = db.open()) {
            Db.run(c, "CREATE TABLE IF NOT EXISTS movies ("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, price INTEGER NOT NULL, "
                    + "genre TEXT, poster TEXT, active INTEGER NOT NULL DEFAULT 1, "
                    + "duration TEXT DEFAULT '', release_date TEXT DEFAULT '', description TEXT DEFAULT '')");

            Db.run(c, "CREATE TABLE IF NOT EXISTS theatres ("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, "
                    + "location TEXT, active INTEGER NOT NULL DEFAULT 1)");

            Db.run(c, "CREATE TABLE IF NOT EXISTS shows ("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT, movie_id INTEGER NOT NULL, theatre_id INTEGER NOT NULL, "
                    + "show_date TEXT NOT NULL, show_time TEXT NOT NULL, language TEXT NOT NULL, "
                    + "active INTEGER NOT NULL DEFAULT 1, "
                    + "FOREIGN KEY(movie_id) REFERENCES movies(id), FOREIGN KEY(theatre_id) REFERENCES theatres(id))");

            Db.run(c, "CREATE TABLE IF NOT EXISTS bookings ("
                    + "booking_id INTEGER PRIMARY KEY, customer TEXT NOT NULL, movie TEXT NOT NULL, "
                    + "tickets INTEGER NOT NULL, seats TEXT NOT NULL, amount INTEGER NOT NULL, "
                    + "payment_method TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'CONFIRMED', "
                    + "show_id INTEGER, theatre_id INTEGER, show_date TEXT, show_time TEXT, language TEXT)");

            // Migrations for databases created by older versions
            addMissingColumns(c, "bookings", new String[][]{
                    {"show_id", "INTEGER"}, {"theatre_id", "INTEGER"}, {"show_date", "TEXT"},
                    {"show_time", "TEXT"}, {"language", "TEXT"}});
            addMissingColumns(c, "movies", new String[][]{
                    {"active", "INTEGER NOT NULL DEFAULT 1"}, {"duration", "TEXT DEFAULT ''"},
                    {"release_date", "TEXT DEFAULT ''"}, {"description", "TEXT DEFAULT ''"}});
            addMissingColumns(c, "theatres", new String[][]{{"active", "INTEGER NOT NULL DEFAULT 1"}});
            addMissingColumns(c, "shows", new String[][]{{"active", "INTEGER NOT NULL DEFAULT 1"}});

            // Indexes
            Db.run(c, "CREATE UNIQUE INDEX IF NOT EXISTS unique_show_index "
                    + "ON shows(movie_id, theatre_id, show_date, show_time, language)");
            Db.run(c, "CREATE INDEX IF NOT EXISTS booking_show_index ON bookings(show_id)");
            Db.run(c, "CREATE INDEX IF NOT EXISTS booking_status_index ON bookings(status)");

            seedMovies(c);
            seedTheatres(c);
            seedShows(c);
        }
    }

    private void addMissingColumns(Connection c, String table, String[][] columns) throws SQLException {
        Set<String> existing = new HashSet<>();
        for (Map<String, Object> row : Db.all(c, "PRAGMA table_info(" + table + ")")) {
            existing.add(String.valueOf(row.get("name")));
        }
        for (String[] column : columns) {
            if (!existing.contains(column[0])) {
                Db.run(c, "ALTER TABLE " + table + " ADD COLUMN " + column[0] + " " + column[1]);
            }
        }
    }

    private void seedMovies(Connection c) throws SQLException {
        if (Db.count(c, "SELECT COUNT(*) FROM movies") > 0) {
            return;
        }
        Object[][] movies = {
                {"Kalki 2898 AD", 250, "Sci-Fi / Action", "/static/images/Salaar_poster.jpg"},
                {"Pushpa 2: The Rule", 200, "Action / Thriller", ""},
                {"Coolie", 220, "Action / Drama", ""},
                {"Darling", 150, "Romance / Comedy", "/static/images/posters/608539_darling.jpeg"},
                {"War 2", 280, "Action / Spy", ""}
        };
        for (Object[] m : movies) {
            Db.run(c, "INSERT INTO movies (name, price, genre, poster, active) VALUES (?, ?, ?, ?, 1)",
                    m[0], m[1], m[2], m[3]);
        }
    }

    private void seedTheatres(Connection c) throws SQLException {
        if (Db.count(c, "SELECT COUNT(*) FROM theatres") > 0) {
            return;
        }
        String[][] theatres = {
                {"PVR Cinemas", "Chennai - VR Mall"},
                {"INOX Cinemas", "Chennai - Marina"},
                {"AGS Cinemas", "Chennai - T Nagar"}
        };
        for (String[] t : theatres) {
            Db.run(c, "INSERT INTO theatres (name, location, active) VALUES (?, ?, 1)", t[0], t[1]);
        }
    }

    /** Makes sure there are always active shows for today and the coming week. */
    private void seedShows(Connection c) throws SQLException {
        LocalDate today = LocalDate.now();
        long upcoming = Db.count(c,
                "SELECT COUNT(*) FROM shows WHERE show_date >= ? AND active = 1", today.toString());
        if (upcoming >= 4) {
            return;
        }
        List<Map<String, Object>> movies = Db.all(c, "SELECT id FROM movies WHERE active = 1");
        List<Map<String, Object>> theatres = Db.all(c, "SELECT id FROM theatres WHERE active = 1");
        if (movies.isEmpty() || theatres.isEmpty()) {
            return;
        }
        String[] times = {"10:00 AM", "01:30 PM", "04:30 PM", "07:30 PM"};
        String[] languages = {"English", "Hindi", "Telugu", "Tamil"};

        boolean autoCommit = c.getAutoCommit();
        c.setAutoCommit(false);
        try (PreparedStatement ps = c.prepareStatement(
                "INSERT OR IGNORE INTO shows (movie_id, theatre_id, show_date, show_time, language, active) "
                        + "VALUES (?, ?, ?, ?, ?, 1)")) {
            for (Map<String, Object> movie : movies) {
                int movieId = Util.toInt(movie.get("id"));
                for (Map<String, Object> theatre : theatres) {
                    for (int day = 0; day < 7; day++) {
                        String date = today.plusDays(day).toString();
                        for (int idx = 0; idx < times.length; idx++) {
                            ps.setInt(1, movieId);
                            ps.setInt(2, Util.toInt(theatre.get("id")));
                            ps.setString(3, date);
                            ps.setString(4, times[idx]);
                            ps.setString(5, languages[(movieId + idx) % languages.length]);
                            ps.addBatch();
                        }
                    }
                }
            }
            ps.executeBatch();
            c.commit();
        } catch (SQLException e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(autoCommit);
        }
    }
}
