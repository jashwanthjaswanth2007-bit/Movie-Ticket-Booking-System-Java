package com.moviebook;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.util.WebUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

/** Administrator API. Every route here is protected by the AdminGuard in Config. */
@RestController
public class AdminController {

    private static final Random RANDOM = new Random();
    private static final String ACTIVE_STATUSES = "status IN ('CONFIRMED', 'PARTIALLY_CANCELLED')";

    private final Db db;
    private final AppSettings settings;

    public AdminController(Db db, AppSettings settings) {
        this.db = db;
        this.settings = settings;
    }

    // ---------- dashboard ----------

    @GetMapping("/api/admin/dashboard")
    public Map<String, Object> dashboard() throws SQLException {
        try (Connection c = db.open()) {
            return Util.map(
                    "success", true,
                    "movies", Db.count(c, "SELECT COUNT(*) FROM movies WHERE active = 1"),
                    "theatres", Db.count(c, "SELECT COUNT(*) FROM theatres WHERE active = 1"),
                    "shows", Db.count(c, "SELECT COUNT(*) FROM shows WHERE active = 1"),
                    "bookings", Db.count(c, "SELECT COUNT(*) FROM bookings"),
                    "revenue", Db.count(c, "SELECT COALESCE(SUM(amount), 0) FROM bookings WHERE " + ACTIVE_STATUSES),
                    "tickets", Db.count(c, "SELECT COALESCE(SUM(tickets), 0) FROM bookings WHERE " + ACTIVE_STATUSES));
        }
    }

    // ---------- poster file helpers ----------

    /** Saves an uploaded poster and returns its public path. */
    private String savePoster(MultipartFile file) throws IOException {
        String filename = Util.secureFilename(file.getOriginalFilename());
        String uniqueName = (System.currentTimeMillis() / 1000) + "_" + (1000 + RANDOM.nextInt(9000)) + "_" + filename;
        Files.createDirectories(settings.posterDir);
        file.transferTo(settings.posterDir.resolve(uniqueName));
        return "/static/images/posters/" + uniqueName;
    }

    private void deletePosterFile(Object poster) {
        if (poster == null) {
            return;
        }
        String path = String.valueOf(poster).replace("\\", "/");
        String filename = path.substring(path.lastIndexOf('/') + 1);
        if (filename.isEmpty()) {
            return;
        }
        Path target = settings.posterDir.resolve(filename).normalize();
        if (!target.startsWith(settings.posterDir)) {
            return;
        }
        try {
            Files.deleteIfExists(target);
        } catch (IOException ignored) {
            // the file stays; not critical
        }
    }

    // ---------- movies ----------

    @GetMapping("/api/admin/movies")
    public Map<String, Object> movies() throws SQLException {
        try (Connection c = db.open()) {
            List<Map<String, Object>> rows = Db.all(c,
                    "SELECT id, name, price, genre, poster, active FROM movies ORDER BY id DESC");
            for (Map<String, Object> row : rows) {
                row.put("poster", Util.normalizePosterPath(row.get("poster")));
            }
            return Util.map("success", true, "movies", rows);
        }
    }

    @PostMapping("/api/admin/movies")
    public ResponseEntity<Map<String, Object>> addMovie(
            @RequestParam(value = "name", defaultValue = "") String nameParam,
            @RequestParam(value = "genre", defaultValue = "") String genreParam,
            @RequestParam(value = "price", defaultValue = "") String priceParam,
            @RequestParam(value = "poster", required = false) MultipartFile file) throws SQLException, IOException {
        String name = nameParam.trim();
        String genre = genreParam.trim();

        if (name.isEmpty()) {
            return Util.fail(400, "Movie name is required.");
        }
        int price;
        try {
            price = Util.toInt(priceParam.trim());
        } catch (RuntimeException e) {
            return Util.fail(400, "Invalid movie price.");
        }
        if (price <= 0) {
            return Util.fail(400, "Price must be greater than zero.");
        }

        String posterPath = "";
        if (file != null && file.getOriginalFilename() != null && !file.getOriginalFilename().isEmpty()) {
            if (!Util.allowedImage(file.getOriginalFilename())) {
                return Util.fail(400, "Invalid poster format. Allowed: PNG, JPG, JPEG, WEBP.");
            }
            posterPath = savePoster(file);
        }

        try (Connection c = db.open()) {
            long id = Db.insert(c,
                    "INSERT INTO movies (name, price, genre, poster, active) VALUES (?, ?, ?, ?, 1)",
                    name, price, genre, posterPath);
            return ResponseEntity.ok(Util.map("success", true, "message", "Movie added successfully.", "id", id));
        }
    }

    @PutMapping("/api/admin/movies/{movieId}")
    public ResponseEntity<Map<String, Object>> updateMovie(@PathVariable("movieId") int movieId,
                                                           HttpServletRequest request)
            throws SQLException, IOException {
        // Accepts both multipart/form data and a JSON body
        Map<String, Object> payload = new HashMap<>();
        MultipartFile file = null;
        String contentType = request.getContentType() == null ? "" : request.getContentType().toLowerCase(Locale.ROOT);
        if (contentType.contains("json")) {
            payload = Util.parseBody(new String(request.getInputStream().readAllBytes(), StandardCharsets.UTF_8));
        } else {
            for (Map.Entry<String, String[]> entry : request.getParameterMap().entrySet()) {
                payload.put(entry.getKey(), entry.getValue().length > 0 ? entry.getValue()[0] : "");
            }
            MultipartHttpServletRequest multipart =
                    WebUtils.getNativeRequest(request, MultipartHttpServletRequest.class);
            if (multipart != null) {
                file = multipart.getFile("poster");
            }
        }

        String name = Util.str(payload.get("name")).trim();
        String genre = Util.str(payload.get("genre")).trim();
        if (name.isEmpty()) {
            return Util.fail(400, "Movie name is required.");
        }
        int price;
        try {
            price = Util.toInt(payload.get("price"));
        } catch (RuntimeException e) {
            return Util.fail(400, "Invalid price.");
        }
        if (price <= 0) {
            return Util.fail(400, "Price must be greater than zero.");
        }

        try (Connection c = db.open()) {
            Map<String, Object> movie = Db.one(c, "SELECT * FROM movies WHERE id = ?", movieId);
            if (movie == null) {
                return Util.fail(404, "Movie not found.");
            }
            String posterPath = Util.str(movie.get("poster"));
            if (file != null && file.getOriginalFilename() != null && !file.getOriginalFilename().isEmpty()) {
                if (!Util.allowedImage(file.getOriginalFilename())) {
                    return Util.fail(400, "Invalid poster format.");
                }
                String newPath = savePoster(file);
                deletePosterFile(movie.get("poster"));
                posterPath = newPath;
            }
            Db.run(c, "UPDATE movies SET name = ?, genre = ?, price = ?, poster = ? WHERE id = ?",
                    name, genre, price, posterPath, movieId);
            return ResponseEntity.ok(Util.map("success", true, "message", "Movie updated successfully."));
        }
    }

    @DeleteMapping("/api/admin/movies/{movieId}")
    public ResponseEntity<Map<String, Object>> deleteMovie(@PathVariable("movieId") int movieId)
            throws SQLException {
        try (Connection c = db.open()) {
            Map<String, Object> movie = Db.one(c, "SELECT * FROM movies WHERE id = ?", movieId);
            if (movie == null) {
                return Util.fail(404, "Movie not found.");
            }
            if (Db.count(c, "SELECT COUNT(*) FROM bookings WHERE movie = ?", movie.get("name")) > 0) {
                return Util.fail(400, "This movie has booking records. Deactivate it instead.");
            }
            if (Db.count(c, "SELECT COUNT(*) FROM shows WHERE movie_id = ?", movieId) > 0) {
                return Util.fail(400, "This movie has scheduled shows. Deactivate it instead.");
            }
            deletePosterFile(movie.get("poster"));
            Db.run(c, "DELETE FROM movies WHERE id = ?", movieId);
            return ResponseEntity.ok(Util.map("success", true, "message", "Movie deleted successfully."));
        }
    }

    @PostMapping("/api/admin/movies/{movieId}/toggle")
    public ResponseEntity<Map<String, Object>> toggleMovie(@PathVariable("movieId") int movieId)
            throws SQLException {
        return toggle("movies", movieId, "Movie not found.");
    }

    /** Flips the active flag of a row in movies, theatres or shows. */
    private ResponseEntity<Map<String, Object>> toggle(String table, int id, String notFound) throws SQLException {
        try (Connection c = db.open()) {
            Map<String, Object> row = Db.one(c, "SELECT active FROM " + table + " WHERE id = ?", id);
            if (row == null) {
                return Util.fail(404, notFound);
            }
            int newStatus = Util.truthy(row.get("active")) ? 0 : 1;
            Db.run(c, "UPDATE " + table + " SET active = ? WHERE id = ?", newStatus, id);
            return ResponseEntity.ok(Util.map("success", true, "active", newStatus == 1));
        }
    }

    // ---------- theatres ----------

    @GetMapping("/api/admin/theatres")
    public Map<String, Object> theatres() throws SQLException {
        try (Connection c = db.open()) {
            return Util.map("success", true, "theatres",
                    Db.all(c, "SELECT id, name, location, active FROM theatres ORDER BY id DESC"));
        }
    }

    @PostMapping("/api/admin/theatres")
    public ResponseEntity<Map<String, Object>> addTheatre(@RequestBody(required = false) String raw)
            throws SQLException {
        Map<String, Object> data = Util.parseBody(raw);
        String name = Util.str(data.get("name")).trim();
        String location = Util.str(data.get("location")).trim();
        if (name.isEmpty()) {
            return Util.fail(400, "Theatre name is required.");
        }
        try (Connection c = db.open()) {
            long id = Db.insert(c, "INSERT INTO theatres (name, location, active) VALUES (?, ?, 1)", name, location);
            return ResponseEntity.ok(Util.map("success", true, "message", "Theatre added successfully.", "id", id));
        } catch (SQLException e) {
            if (Util.isConstraintError(e)) {
                return Util.fail(409, "A theatre with this name already exists.");
            }
            throw e;
        }
    }

    @PutMapping("/api/admin/theatres/{theatreId}")
    public ResponseEntity<Map<String, Object>> updateTheatre(@PathVariable("theatreId") int theatreId,
                                                             @RequestBody(required = false) String raw)
            throws SQLException {
        Map<String, Object> data = Util.parseBody(raw);
        String name = Util.str(data.get("name")).trim();
        String location = Util.str(data.get("location")).trim();
        if (name.isEmpty()) {
            return Util.fail(400, "Theatre name is required.");
        }
        try (Connection c = db.open()) {
            if (Db.one(c, "SELECT id FROM theatres WHERE id = ?", theatreId) == null) {
                return Util.fail(404, "Theatre not found.");
            }
            Db.run(c, "UPDATE theatres SET name = ?, location = ? WHERE id = ?", name, location, theatreId);
            return ResponseEntity.ok(Util.map("success", true, "message", "Theatre updated successfully."));
        } catch (SQLException e) {
            if (Util.isConstraintError(e)) {
                return Util.fail(409, "Another theatre already has this name.");
            }
            throw e;
        }
    }

    @DeleteMapping("/api/admin/theatres/{theatreId}")
    public ResponseEntity<Map<String, Object>> deleteTheatre(@PathVariable("theatreId") int theatreId)
            throws SQLException {
        try (Connection c = db.open()) {
            if (Db.one(c, "SELECT id FROM theatres WHERE id = ?", theatreId) == null) {
                return Util.fail(404, "Theatre not found.");
            }
            if (Db.count(c, "SELECT COUNT(*) FROM shows WHERE theatre_id = ?", theatreId) > 0) {
                return Util.fail(400, "This theatre has scheduled shows. Deactivate it instead.");
            }
            Db.run(c, "DELETE FROM theatres WHERE id = ?", theatreId);
            return ResponseEntity.ok(Util.map("success", true, "message", "Theatre deleted successfully."));
        }
    }

    @PostMapping("/api/admin/theatres/{theatreId}/toggle")
    public ResponseEntity<Map<String, Object>> toggleTheatre(@PathVariable("theatreId") int theatreId)
            throws SQLException {
        return toggle("theatres", theatreId, "Theatre not found.");
    }

    // ---------- shows ----------

    @GetMapping("/api/admin/shows")
    public Map<String, Object> shows() throws SQLException {
        try (Connection c = db.open()) {
            return Util.map("success", true, "shows", Db.all(c,
                    "SELECT s.id, s.movie_id, s.theatre_id, s.show_date, s.show_time, s.language, s.active, "
                            + "m.name AS movie_name, m.price, t.name AS theatre_name, t.location AS theatre_location "
                            + "FROM shows s JOIN movies m ON m.id = s.movie_id JOIN theatres t ON t.id = s.theatre_id "
                            + "ORDER BY s.show_date DESC, s.show_time ASC"));
        }
    }

    @PostMapping("/api/admin/shows")
    public ResponseEntity<Map<String, Object>> addShow(@RequestBody(required = false) String raw)
            throws SQLException {
        Map<String, Object> data = Util.parseBody(raw);
        int movieId;
        int theatreId;
        try {
            movieId = Util.toInt(data.get("movie_id"));
            theatreId = Util.toInt(data.get("theatre_id"));
        } catch (RuntimeException e) {
            return Util.fail(400, "Invalid movie or theatre selection.");
        }
        String showDate = Util.str(data.get("show_date")).trim();
        String showTime = Util.str(data.get("show_time")).trim();
        String language = Util.str(data.get("language")).trim();
        if (showDate.isEmpty() || showTime.isEmpty() || language.isEmpty()) {
            return Util.fail(400, "Date, show time, and language are all required.");
        }

        try (Connection c = db.open()) {
            if (Db.one(c, "SELECT id FROM movies WHERE id = ?", movieId) == null) {
                return Util.fail(404, "Movie not found.");
            }
            if (Db.one(c, "SELECT id FROM theatres WHERE id = ?", theatreId) == null) {
                return Util.fail(404, "Theatre not found.");
            }
            long id = Db.insert(c, "INSERT INTO shows (movie_id, theatre_id, show_date, show_time, language, active) "
                    + "VALUES (?, ?, ?, ?, ?, 1)", movieId, theatreId, showDate, showTime, language);
            return ResponseEntity.ok(Util.map("success", true, "message", "Show scheduled successfully.", "id", id));
        } catch (SQLException e) {
            if (Util.isConstraintError(e)) {
                return Util.fail(409, "Another show with the exact same schedule already exists.");
            }
            throw e;
        }
    }

    @PutMapping("/api/admin/shows/{showId}")
    public ResponseEntity<Map<String, Object>> updateShow(@PathVariable("showId") int showId,
                                                          @RequestBody(required = false) String raw)
            throws SQLException {
        Map<String, Object> data = Util.parseBody(raw);
        int movieId;
        int theatreId;
        try {
            movieId = Util.toInt(data.get("movie_id"));
            theatreId = Util.toInt(data.get("theatre_id"));
        } catch (RuntimeException e) {
            return Util.fail(400, "Invalid movie or theatre.");
        }
        String showDate = Util.str(data.get("show_date")).trim();
        String showTime = Util.str(data.get("show_time")).trim();
        String language = Util.str(data.get("language")).trim();
        if (showDate.isEmpty() || showTime.isEmpty() || language.isEmpty()) {
            return Util.fail(400, "All show fields are required.");
        }

        try (Connection c = db.open()) {
            if (Db.one(c, "SELECT id FROM shows WHERE id = ?", showId) == null) {
                return Util.fail(404, "Show not found.");
            }
            if (Db.count(c, "SELECT COUNT(*) FROM bookings WHERE show_id = ?", showId) > 0) {
                return Util.fail(400, "This show has active booking records and cannot be modified.");
            }
            Db.run(c, "UPDATE shows SET movie_id = ?, theatre_id = ?, show_date = ?, show_time = ?, language = ? "
                    + "WHERE id = ?", movieId, theatreId, showDate, showTime, language, showId);
            return ResponseEntity.ok(Util.map("success", true, "message", "Show schedule updated successfully."));
        } catch (SQLException e) {
            if (Util.isConstraintError(e)) {
                return Util.fail(409, "Another show with the same schedule already exists.");
            }
            throw e;
        }
    }

    @DeleteMapping("/api/admin/shows/{showId}")
    public ResponseEntity<Map<String, Object>> deleteShow(@PathVariable("showId") int showId)
            throws SQLException {
        try (Connection c = db.open()) {
            if (Db.one(c, "SELECT id FROM shows WHERE id = ?", showId) == null) {
                return Util.fail(404, "Show not found.");
            }
            if (Db.count(c, "SELECT COUNT(*) FROM bookings WHERE show_id = ?", showId) > 0) {
                return Util.fail(400, "This show has booking records. Deactivate it instead.");
            }
            Db.run(c, "DELETE FROM shows WHERE id = ?", showId);
            return ResponseEntity.ok(Util.map("success", true, "message", "Show schedule deleted successfully."));
        }
    }

    @PostMapping("/api/admin/shows/{showId}/toggle")
    public ResponseEntity<Map<String, Object>> toggleShow(@PathVariable("showId") int showId)
            throws SQLException {
        return toggle("shows", showId, "Show schedule not found.");
    }

    // ---------- bookings ----------

    @GetMapping("/api/admin/bookings")
    public Map<String, Object> bookings() throws SQLException {
        try (Connection c = db.open()) {
            List<Map<String, Object>> rows = Db.all(c,
                    "SELECT b.*, t.name AS theatre_name, t.location AS theatre_location "
                            + "FROM bookings b LEFT JOIN theatres t ON t.id = b.theatre_id "
                            + "ORDER BY b.booking_id DESC");
            List<Map<String, Object>> bookings = new ArrayList<>();
            for (Map<String, Object> row : rows) {
                Map<String, Object> item = new LinkedHashMap<>(row);
                item.put("seats", Util.parseSeats(row.get("seats")));
                bookings.add(item);
            }
            return Util.map("success", true, "bookings", bookings);
        }
    }

    @PostMapping("/api/admin/bookings/{bookingId}/confirm")
    public ResponseEntity<Map<String, Object>> confirmBooking(@PathVariable("bookingId") int bookingId)
            throws SQLException {
        try (Connection c = db.open()) {
            Map<String, Object> booking = Db.one(c, "SELECT * FROM bookings WHERE booking_id = ?", bookingId);
            if (booking == null) {
                return Util.fail(404, "Booking not found.");
            }
            if ("CANCELLED".equals(booking.get("status"))) {
                return Util.fail(400, "A fully cancelled booking cannot be directly confirmed.");
            }
            Db.run(c, "UPDATE bookings SET status = 'CONFIRMED' WHERE booking_id = ?", bookingId);
            return ResponseEntity.ok(Util.map("success", true, "message", "Booking confirmed successfully."));
        }
    }

    // ---------- revenue ----------

    @GetMapping("/api/admin/revenue")
    public Map<String, Object> revenue() throws SQLException {
        try (Connection c = db.open()) {
            List<Map<String, Object>> paymentMethods = Db.all(c,
                    "SELECT payment_method, COUNT(*) AS booking_count, COALESCE(SUM(amount), 0) AS revenue "
                            + "FROM bookings WHERE " + ACTIVE_STATUSES
                            + " GROUP BY payment_method ORDER BY revenue DESC");
            return Util.map(
                    "success", true,
                    "total_revenue", Db.count(c,
                            "SELECT COALESCE(SUM(amount), 0) FROM bookings WHERE " + ACTIVE_STATUSES),
                    "tickets_sold", Db.count(c,
                            "SELECT COALESCE(SUM(tickets), 0) FROM bookings WHERE " + ACTIVE_STATUSES),
                    "confirmed_bookings", Db.count(c, "SELECT COUNT(*) FROM bookings WHERE status = 'CONFIRMED'"),
                    "partial_bookings", Db.count(c,
                            "SELECT COUNT(*) FROM bookings WHERE status = 'PARTIALLY_CANCELLED'"),
                    "cancelled_bookings", Db.count(c, "SELECT COUNT(*) FROM bookings WHERE status = 'CANCELLED'"),
                    "payment_methods", paymentMethods);
        }
    }
}
