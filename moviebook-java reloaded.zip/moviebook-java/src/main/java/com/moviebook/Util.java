package com.moviebook;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.ResponseEntity;

import java.sql.SQLException;
import java.text.Normalizer;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Shared helpers: JSON responses, parsing, poster paths and show-time logic. */
public final class Util {

    public static final ObjectMapper MAPPER = new ObjectMapper();

    private Util() {
    }

    // ---------- responses ----------

    /** Builds an ordered map from key, value, key, value ... */
    public static Map<String, Object> map(Object... keyValues) {
        Map<String, Object> result = new LinkedHashMap<>();
        for (int i = 0; i + 1 < keyValues.length; i += 2) {
            result.put(String.valueOf(keyValues[i]), keyValues[i + 1]);
        }
        return result;
    }

    public static ResponseEntity<Map<String, Object>> fail(int status, String message) {
        return ResponseEntity.status(status).body(map("success", false, "message", message));
    }

    // ---------- parsing ----------

    /** Parses a JSON object body; returns an empty map when the body is missing or invalid. */
    public static Map<String, Object> parseBody(String raw) {
        if (raw == null || raw.isBlank()) {
            return new LinkedHashMap<>();
        }
        try {
            Map<String, Object> parsed = MAPPER.readValue(raw, new TypeReference<Map<String, Object>>() {
            });
            return parsed == null ? new LinkedHashMap<>() : parsed;
        } catch (Exception e) {
            return new LinkedHashMap<>();
        }
    }

    public static String str(Object value) {
        return value == null ? "" : String.valueOf(value);
    }

    /** Converts a number or numeric string to int; throws NumberFormatException otherwise. */
    public static int toInt(Object value) {
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        if (value instanceof String) {
            return Integer.parseInt(((String) value).trim());
        }
        throw new NumberFormatException("Not a number: " + value);
    }

    /** Lenient integer query parameter: null when missing or not a number. */
    public static Integer optInt(String value) {
        if (value == null) {
            return null;
        }
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static boolean truthy(Object value) {
        if (value instanceof Number) {
            return ((Number) value).intValue() != 0;
        }
        return value != null && !String.valueOf(value).isEmpty();
    }

    public static boolean isConstraintError(SQLException e) {
        String message = String.valueOf(e.getMessage());
        return message.contains("UNIQUE") || message.contains("CONSTRAINT");
    }

    // ---------- seats stored as a JSON array in bookings.seats ----------

    public static List<Integer> parseSeats(Object json) {
        List<Integer> seats = new ArrayList<>();
        try {
            List<Object> raw = MAPPER.readValue(str(json), new TypeReference<List<Object>>() {
            });
            for (Object item : raw) {
                seats.add(toInt(item));
            }
        } catch (Exception e) {
            // invalid or empty JSON means no seats
        }
        return seats;
    }

    public static String seatsToJson(Collection<Integer> seats) {
        try {
            return MAPPER.writeValueAsString(seats);
        } catch (Exception e) {
            return "[]";
        }
    }

    // ---------- posters ----------

    public static String normalizePosterPath(Object posterValue) {
        if (posterValue == null) {
            return "";
        }
        String poster = String.valueOf(posterValue).replace("\\", "/");
        if (poster.isEmpty()) {
            return "";
        }
        if (poster.startsWith("http://") || poster.startsWith("https://")) {
            return poster;
        }
        if (poster.startsWith("/static/")) {
            return poster;
        }
        if (poster.startsWith("static/")) {
            return "/" + poster;
        }
        if (!poster.startsWith("/")) {
            return "/static/images/posters/" + poster;
        }
        return poster;
    }

    public static boolean allowedImage(String filename) {
        int dot = filename.lastIndexOf('.');
        if (dot < 0) {
            return false;
        }
        return AppSettings.IMAGE_EXTENSIONS.contains(filename.substring(dot + 1).toLowerCase(Locale.ROOT));
    }

    /** Keeps only safe characters in an uploaded file name. */
    public static String secureFilename(String name) {
        String n = name.replace("\\", "/");
        n = n.substring(n.lastIndexOf('/') + 1);
        n = Normalizer.normalize(n, Normalizer.Form.NFKD).replaceAll("[^A-Za-z0-9._ -]", "");
        n = n.trim().replace(' ', '_').replaceAll("^[._]+|[._]+$", "");
        return n.isEmpty() ? "poster" : n;
    }

    // ---------- show date and time ----------

    private static final String[] TIME_PATTERNS = {
            "uuuu-M-d h:mm a",
            "uuuu-M-d h:mma",
            "uuuu-M-d H:mm:ss",
            "uuuu-M-d H:mm",
            "uuuu-M-d h:mm:ss a"
    };

    private static final List<DateTimeFormatter> FORMATS = new ArrayList<>();

    static {
        for (String pattern : TIME_PATTERNS) {
            FORMATS.add(new DateTimeFormatterBuilder()
                    .parseCaseInsensitive()
                    .appendPattern(pattern)
                    .toFormatter(Locale.ENGLISH)
                    .withResolverStyle(ResolverStyle.SMART));
        }
    }

    /** Parses a show date and time written in 12-hour or 24-hour format. */
    public static LocalDateTime parseShowDateTime(String showDate, String showTime) {
        if (showDate == null || showTime == null || showDate.isBlank() || showTime.isBlank()) {
            return null;
        }
        String raw = showDate.trim() + " " + showTime.trim();
        for (DateTimeFormatter format : FORMATS) {
            try {
                return LocalDateTime.parse(raw, format);
            } catch (Exception e) {
                // try the next format
            }
        }
        return null;
    }

    public static LocalDateTime localNow(AppSettings settings) {
        return LocalDateTime.now(ZoneOffset.UTC).plusMinutes(settings.utcOffsetMinutes);
    }

    public static boolean showHasStarted(AppSettings settings, String showDate, String showTime) {
        LocalDateTime start = parseShowDateTime(showDate, showTime);
        if (start == null) {
            return false;
        }
        return !start.isAfter(localNow(settings));
    }
}
