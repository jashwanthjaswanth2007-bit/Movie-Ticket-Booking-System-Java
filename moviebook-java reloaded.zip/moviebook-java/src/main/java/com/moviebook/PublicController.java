package com.moviebook;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

/** Customer-facing API: movies, theatres, shows, seats, booking and cancellation. */
@RestController
public class PublicController {

    private static final String ACTIVE_STATUSES = "status IN ('CONFIRMED', 'PARTIALLY_CANCELLED')";
    private static final Random RANDOM = new Random();

    private final Db db;
    private final AppSettings settings;

    public PublicController(Db db, AppSettings settings) {
        this.db = db;
        this.settings = settings;
    }

    // ---------- shared helpers ----------

    static Map<String, Object> showDetails(Connection c, int showId) throws SQLException {
        return Db.one(c,
                "SELECT s.id, s.movie_id, s.theatre_id, s.show_date, s.show_time, s.language, s.active, "
                        + "m.name AS movie_name, m.price, m.poster, m.genre, "
                        + "t.name AS theatre_name, t.location AS theatre_location "
                        + "FROM shows s JOIN movies m ON m.id = s.movie_id JOIN theatres t ON t.id = s.theatre_id "
                        + "WHERE s.id = ?", showId);
    }

    static Map<String, Object> bookingToMap(Connection c, Map<String, Object> booking) throws SQLException {
        String theatreName = "";
        String theatreLocation = "";
        Object theatreId = booking.get("theatre_id");
        if (Util.truthy(theatreId)) {
            Map<String, Object> theatre = Db.one(c, "SELECT name, location FROM theatres WHERE id = ?", theatreId);
            if (theatre != null) {
                theatreName = Util.str(theatre.get("name"));
                theatreLocation = Util.str(theatre.get("location"));
            }
        }
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("booking_id", booking.get("booking_id"));
        result.put("customer", booking.get("customer"));
        result.put("movie", booking.get("movie"));
        result.put("theatre", theatreName);
        result.put("theatre_name", theatreName);
        result.put("theatre_location", theatreLocation);
        result.put("show_date", booking.get("show_date"));
        result.put("show_time", booking.get("show_time"));
        result.put("language", booking.get("language"));
        result.put("tickets", booking.get("tickets"));
        result.put("seats", Util.parseSeats(booking.get("seats")));
        result.put("amount", booking.get("amount"));
        result.put("payment_method", booking.get("payment_method"));
        result.put("status", booking.get("status"));
        result.put("show_id", booking.get("show_id"));
        result.put("theatre_id", booking.get("theatre_id"));
        return result;
    }

    private static Set<Integer> bookedSeats(Connection c, int showId) throws SQLException {
        Set<Integer> booked = new HashSet<>();
        for (Map<String, Object> row : Db.all(c,
                "SELECT seats FROM bookings WHERE show_id = ? AND " + ACTIVE_STATUSES, showId)) {
            booked.addAll(Util.parseSeats(row.get("seats")));
        }
        return booked;
    }

    /** Parses a list of seat numbers: sorted and without duplicates. Throws on bad values. */
    private static TreeSet<Integer> toSeatSet(List<?> raw) {
        TreeSet<Integer> seats = new TreeSet<>();
        for (Object item : raw) {
            seats.add(Util.toInt(item));
        }
        return seats;
    }

    // ---------- movies, theatres, shows ----------

    @GetMapping("/api/movies")
    public Map<String, Object> movies() throws SQLException {
        try (Connection c = db.open()) {
            List<Map<String, Object>> rows = Db.all(c,
                    "SELECT id, name, price, genre, poster, active FROM movies WHERE active = 1 ORDER BY id DESC");
            for (Map<String, Object> row : rows) {
                row.put("poster", Util.normalizePosterPath(row.get("poster")));
            }
            return Util.map("success", true, "movies", rows);
        }
    }

    @GetMapping("/api/theatres")
    public Map<String, Object> theatres(@RequestParam(value = "movie_id", required = false) String movieIdParam)
            throws SQLException {
        Integer movieId = Util.optInt(movieIdParam);
        try (Connection c = db.open()) {
            List<Map<String, Object>> rows;
            if (movieId != null && movieId != 0) {
                rows = Db.all(c,
                        "SELECT DISTINCT t.id, t.name, t.location FROM theatres t "
                                + "JOIN shows s ON s.theatre_id = t.id "
                                + "WHERE t.active = 1 AND s.active = 1 AND s.movie_id = ? ORDER BY t.name", movieId);
            } else {
                rows = Db.all(c, "SELECT id, name, location FROM theatres WHERE active = 1 ORDER BY name");
            }
            return Util.map("success", true, "theatres", rows);
        }
    }

    @GetMapping("/api/shows")
    public Map<String, Object> shows(@RequestParam(value = "movie_id", required = false) String movieIdParam,
                                     @RequestParam(value = "theatre_id", required = false) String theatreIdParam,
                                     @RequestParam(value = "show_date", required = false) String showDate)
            throws SQLException {
        Integer movieId = Util.optInt(movieIdParam);
        Integer theatreId = Util.optInt(theatreIdParam);

        StringBuilder sql = new StringBuilder(
                "SELECT s.id, s.movie_id, s.theatre_id, s.show_date, s.show_time, s.language, s.active, "
                        + "m.name AS movie_name, m.price, m.poster, "
                        + "t.name AS theatre_name, t.location AS theatre_location "
                        + "FROM shows s JOIN movies m ON m.id = s.movie_id JOIN theatres t ON t.id = s.theatre_id "
                        + "WHERE s.active = 1 AND m.active = 1 AND t.active = 1");
        List<Object> params = new ArrayList<>();
        if (movieId != null && movieId != 0) {
            sql.append(" AND s.movie_id = ?");
            params.add(movieId);
        }
        if (theatreId != null && theatreId != 0) {
            sql.append(" AND s.theatre_id = ?");
            params.add(theatreId);
        }
        if (showDate != null && !showDate.isEmpty()) {
            sql.append(" AND s.show_date = ?");
            params.add(showDate);
        }
        sql.append(" ORDER BY s.show_date, s.show_time");

        List<Map<String, Object>> upcoming = new ArrayList<>();
        try (Connection c = db.open()) {
            for (Map<String, Object> row : Db.all(c, sql.toString(), params.toArray())) {
                // Hide shows that have already started
                if (!Util.showHasStarted(settings, Util.str(row.get("show_date")), Util.str(row.get("show_time")))) {
                    row.put("poster", Util.normalizePosterPath(row.get("poster")));
                    upcoming.add(row);
                }
            }
        }
        return Util.map("success", true, "shows", upcoming);
    }

    @GetMapping("/api/show/{showId}")
    public ResponseEntity<Map<String, Object>> show(@PathVariable("showId") int showId) throws SQLException {
        try (Connection c = db.open()) {
            Map<String, Object> show = showDetails(c, showId);
            if (show == null) {
                return Util.fail(404, "Show not found.");
            }
            Map<String, Object> out = new LinkedHashMap<>();
            for (String key : new String[]{"id", "movie_id", "theatre_id", "show_date", "show_time",
                    "language", "active", "movie_name", "price", "poster", "genre", "theatre_name",
                    "theatre_location"}) {
                out.put(key, show.get(key));
            }
            out.put("poster", Util.normalizePosterPath(show.get("poster")));
            return ResponseEntity.ok(Util.map("success", true, "show", out));
        }
    }

    // ---------- seats ----------

    @GetMapping("/api/seats")
    public Map<String, Object> seats(@RequestParam(value = "show_id", required = false) String showIdParam,
                                     @RequestParam(value = "movie", required = false) String movie)
            throws SQLException {
        Integer showId = Util.optInt(showIdParam);
        List<Map<String, Object>> rows;
        try (Connection c = db.open()) {
            if (showId != null && showId != 0) {
                rows = Db.all(c, "SELECT seats FROM bookings WHERE show_id = ? AND " + ACTIVE_STATUSES, showId);
            } else {
                if (movie == null || movie.isEmpty()) {
                    return Util.map("success", true, "booked_seats", new ArrayList<Integer>());
                }
                rows = Db.all(c, "SELECT seats FROM bookings WHERE movie = ? AND " + ACTIVE_STATUSES, movie);
            }
        }
        TreeSet<Integer> booked = new TreeSet<>();
        for (Map<String, Object> row : rows) {
            booked.addAll(Util.parseSeats(row.get("seats")));
        }
        return Util.map("success", true, "booked_seats", new ArrayList<>(booked));
    }

    // ---------- create booking ----------

    @PostMapping("/api/create-booking")
    public ResponseEntity<Map<String, Object>> createBooking(@RequestBody(required = false) String raw)
            throws SQLException {
        Map<String, Object> data = Util.parseBody(raw);

        String customer = Util.str(data.get("customer")).trim();
        String paymentMethod = Util.str(data.get("payment_method")).trim();

        if (customer.isEmpty()) {
            return Util.fail(400, "Customer name is required.");
        }

        int showId;
        try {
            showId = Util.toInt(data.get("show_id"));
        } catch (RuntimeException e) {
            return Util.fail(400, "Invalid show selected.");
        }

        if (!AppSettings.PAYMENT_METHODS.contains(paymentMethod)) {
            return Util.fail(400, "Invalid payment method.");
        }

        Object rawSeats = data.get("seats");
        if (rawSeats == null) {
            rawSeats = new ArrayList<Object>();
        }
        if (!(rawSeats instanceof List)) {
            return Util.fail(400, "Invalid seats format.");
        }
        TreeSet<Integer> seats;
        try {
            seats = toSeatSet((List<?>) rawSeats);
        } catch (RuntimeException e) {
            return Util.fail(400, "Invalid seat numbers.");
        }
        if (seats.isEmpty()) {
            return Util.fail(400, "Please select at least one seat.");
        }
        for (int seat : seats) {
            if (seat < 1 || seat > AppSettings.TOTAL_SEATS) {
                return Util.fail(400, "Seat numbers must be between 1 and " + AppSettings.TOTAL_SEATS + ".");
            }
        }

        Connection c = db.open();
        boolean committed = false;
        try {
            // IMMEDIATE transaction: the write lock is taken now, so two people
            // can never book the same seat at the same time.
            c.setAutoCommit(false);

            Map<String, Object> show = showDetails(c, showId);
            if (show == null) {
                return Util.fail(404, "Show not found.");
            }
            if (!Util.truthy(show.get("active"))) {
                return Util.fail(400, "This show schedule is no longer active.");
            }
            if (Util.showHasStarted(settings, Util.str(show.get("show_date")), Util.str(show.get("show_time")))) {
                return Util.fail(400, "This show has already started or concluded.");
            }

            Set<Integer> booked = bookedSeats(c, showId);
            List<Integer> unavailable = new ArrayList<>();
            for (int seat : seats) {
                if (booked.contains(seat)) {
                    unavailable.add(seat);
                }
            }
            if (!unavailable.isEmpty()) {
                return ResponseEntity.status(409).body(Util.map(
                        "success", false,
                        "message", "Some selected seats are already booked.",
                        "booked_seats", unavailable));
            }

            int tickets = seats.size();
            int amount = tickets * Util.toInt(show.get("price"));

            int bookingId = -1;
            for (int attempt = 0; attempt < 30; attempt++) {
                int candidate = 10000 + RANDOM.nextInt(90000);
                if (Db.one(c, "SELECT booking_id FROM bookings WHERE booking_id = ?", candidate) == null) {
                    bookingId = candidate;
                    break;
                }
            }
            if (bookingId == -1) {
                return Util.fail(500, "Unable to generate booking ID. Please try again.");
            }

            Db.run(c, "INSERT INTO bookings (booking_id, customer, movie, tickets, seats, amount, "
                            + "payment_method, status, show_id, theatre_id, show_date, show_time, language) "
                            + "VALUES (?, ?, ?, ?, ?, ?, ?, 'CONFIRMED', ?, ?, ?, ?, ?)",
                    bookingId, customer, show.get("movie_name"), tickets, Util.seatsToJson(seats), amount,
                    paymentMethod, showId, show.get("theatre_id"), show.get("show_date"),
                    show.get("show_time"), show.get("language"));

            c.commit();
            committed = true;
            c.setAutoCommit(true);

            Map<String, Object> booking = Db.one(c, "SELECT * FROM bookings WHERE booking_id = ?", bookingId);
            Map<String, Object> result = bookingToMap(c, booking);
            result.put("poster", Util.normalizePosterPath(show.get("poster")));
            result.put("genre", Util.str(show.get("genre")));

            Map<String, Object> response = new LinkedHashMap<>();
            response.put("success", true);
            response.putAll(result);
            return ResponseEntity.ok(response);
        } finally {
            if (!committed) {
                try {
                    c.rollback();
                } catch (SQLException ignored) {
                    // nothing to roll back
                }
            }
            c.close();
        }
    }

    // ---------- booking lookup ----------

    @GetMapping("/api/booking/{bookingId}")
    public ResponseEntity<Map<String, Object>> booking(@PathVariable("bookingId") int bookingId)
            throws SQLException {
        try (Connection c = db.open()) {
            Map<String, Object> booking = Db.one(c, "SELECT * FROM bookings WHERE booking_id = ?", bookingId);
            if (booking == null) {
                return Util.fail(404, "Booking not found.");
            }
            Map<String, Object> result = bookingToMap(c, booking);
            Map<String, Object> response = new LinkedHashMap<>();
            response.put("success", true);
            response.put("booking", result);
            response.putAll(result);
            return ResponseEntity.ok(response);
        }
    }

    /** "My Bookings": only returns the booking IDs the browser asks for. */
    @GetMapping("/api/bookings")
    public Map<String, Object> bookings(@RequestParam(value = "ids", defaultValue = "") String idsParam)
            throws SQLException {
        List<Integer> ids = new ArrayList<>();
        for (String part : idsParam.split(",")) {
            String trimmed = part.trim();
            if (!trimmed.isEmpty() && trimmed.chars().allMatch(Character::isDigit) && trimmed.length() < 10) {
                ids.add(Integer.parseInt(trimmed));
            }
        }
        if (ids.size() > 50) {
            ids = ids.subList(0, 50);
        }
        if (ids.isEmpty()) {
            return Util.map("success", true, "bookings", new ArrayList<Object>());
        }

        StringBuilder placeholders = new StringBuilder();
        for (int i = 0; i < ids.size(); i++) {
            placeholders.append(i == 0 ? "?" : ",?");
        }
        try (Connection c = db.open()) {
            List<Map<String, Object>> rows = Db.all(c,
                    "SELECT * FROM bookings WHERE booking_id IN (" + placeholders + ") ORDER BY booking_id DESC",
                    ids.toArray());
            List<Map<String, Object>> bookings = new ArrayList<>();
            for (Map<String, Object> row : rows) {
                bookings.add(bookingToMap(c, row));
            }
            return Util.map("success", true, "bookings", bookings);
        }
    }

    // ---------- cancellation ----------

    @PostMapping("/api/cancel-booking")
    public ResponseEntity<Map<String, Object>> cancelBooking(@RequestBody(required = false) String raw)
            throws SQLException {
        Map<String, Object> data = Util.parseBody(raw);
        int bookingId;
        try {
            bookingId = Util.toInt(data.get("booking_id"));
        } catch (RuntimeException e) {
            return Util.fail(400, "Invalid booking ID.");
        }
        try (Connection c = db.open()) {
            Map<String, Object> booking = Db.one(c, "SELECT * FROM bookings WHERE booking_id = ?", bookingId);
            if (booking == null) {
                return Util.fail(404, "Booking not found.");
            }
            if ("CANCELLED".equals(booking.get("status"))) {
                return Util.fail(400, "Booking is already cancelled.");
            }
            Db.run(c, "UPDATE bookings SET tickets = 0, seats = '[]', amount = 0, status = 'CANCELLED' "
                    + "WHERE booking_id = ?", bookingId);
            return ResponseEntity.ok(Util.map("success", true, "message", "Booking cancelled successfully."));
        }
    }

    @PostMapping("/api/cancel-seats")
    public ResponseEntity<Map<String, Object>> cancelSeats(@RequestBody(required = false) String raw)
            throws SQLException {
        Map<String, Object> data = Util.parseBody(raw);

        int bookingId;
        try {
            bookingId = Util.toInt(data.get("booking_id"));
        } catch (RuntimeException e) {
            return Util.fail(400, "Invalid booking ID.");
        }

        Object rawSeats = data.get("seats");
        if (rawSeats == null) {
            rawSeats = new ArrayList<Object>();
        }
        if (!(rawSeats instanceof List)) {
            return Util.fail(400, "Invalid seats selection.");
        }
        TreeSet<Integer> selected;
        try {
            selected = toSeatSet((List<?>) rawSeats);
        } catch (RuntimeException e) {
            return Util.fail(400, "Invalid seat numbers.");
        }
        if (selected.isEmpty()) {
            return Util.fail(400, "Please select seats to cancel.");
        }

        try (Connection c = db.open()) {
            Map<String, Object> booking = Db.one(c, "SELECT * FROM bookings WHERE booking_id = ?", bookingId);
            if (booking == null) {
                return Util.fail(404, "Booking not found.");
            }
            if ("CANCELLED".equals(booking.get("status"))) {
                return Util.fail(400, "Booking is already cancelled.");
            }

            List<Integer> current = Util.parseSeats(booking.get("seats"));
            if (current.isEmpty()) {
                return Util.fail(400, "No active seats remain on this booking.");
            }

            List<Integer> invalid = new ArrayList<>();
            for (int seat : selected) {
                if (!current.contains(seat)) {
                    invalid.add(seat);
                }
            }
            if (!invalid.isEmpty()) {
                return ResponseEntity.status(400).body(Util.map(
                        "success", false,
                        "message", "Some selected seats do not belong to this booking.",
                        "invalid_seats", invalid));
            }

            List<Integer> remaining = new ArrayList<>();
            for (int seat : current) {
                if (!selected.contains(seat)) {
                    remaining.add(seat);
                }
            }

            int tickets = Util.toInt(booking.get("tickets"));
            double perTicket = tickets != 0 ? Util.toInt(booking.get("amount")) / (double) tickets : 0;
            int newAmount = (int) Math.rint(remaining.size() * perTicket);

            String newStatus;
            if (remaining.isEmpty()) {
                Db.run(c, "UPDATE bookings SET tickets = 0, seats = '[]', amount = 0, status = 'CANCELLED' "
                        + "WHERE booking_id = ?", bookingId);
                newStatus = "CANCELLED";
            } else {
                Db.run(c, "UPDATE bookings SET tickets = ?, seats = ?, amount = ?, "
                                + "status = 'PARTIALLY_CANCELLED' WHERE booking_id = ?",
                        remaining.size(), Util.seatsToJson(remaining), newAmount, bookingId);
                newStatus = "PARTIALLY_CANCELLED";
            }

            return ResponseEntity.ok(Util.map(
                    "success", true,
                    "status", newStatus,
                    "remaining_seats", remaining,
                    "amount", newAmount,
                    "message", "Selected seats cancelled successfully."));
        }
    }
}
