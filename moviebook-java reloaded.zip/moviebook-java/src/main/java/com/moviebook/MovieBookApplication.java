package com.moviebook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieBookApplication {

    public static void main(String[] args) {
        SpringApplication.run(MovieBookApplication.class, args);
        String port = System.getenv("PORT") == null ? "5000" : System.getenv("PORT");
        System.out.println();
        System.out.println("=============================================");
        System.out.println("              MOVIEBOOK WEB APP");
        System.out.println("=============================================");
        System.out.println(" * Public Site:   http://127.0.0.1:" + port);
        System.out.println(" * Admin Portal:  http://127.0.0.1:" + port + "/admin");
        System.out.println(" * Admin Login:   http://127.0.0.1:" + port + "/admin/login");
        System.out.println("=============================================");
        System.out.println();
    }
}
