package com.moviebook;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.HtmlUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Map;

/** HTML pages, admin login/logout and the health check. */
@RestController
public class PageController {

    private final AppSettings settings;

    public PageController(AppSettings settings) {
        this.settings = settings;
    }

    private static String template(String name) throws IOException {
        return StreamUtils.copyToString(
                new ClassPathResource("templates/" + name).getInputStream(), StandardCharsets.UTF_8);
    }

    private static ResponseEntity<String> html(String body) {
        return ResponseEntity.ok().contentType(MediaType.TEXT_HTML).body(body);
    }

    private static ResponseEntity<String> redirect(String location) {
        return ResponseEntity.status(HttpStatus.FOUND).header(HttpHeaders.LOCATION, location).build();
    }

    @GetMapping("/healthz")
    public Map<String, Object> healthz() {
        return Util.map("status", "ok", "app", "MovieBook");
    }

    @GetMapping("/")
    public ResponseEntity<String> home() throws IOException {
        return html(template("index.html"));
    }

    @GetMapping("/admin")
    public ResponseEntity<String> admin() throws IOException {
        return html(template("admin.html"));
    }

    // ---------- admin login ----------

    @GetMapping("/admin/login")
    public ResponseEntity<String> loginPage(HttpServletRequest request) throws IOException {
        if (Config.isAdmin(request)) {
            return redirect("/admin");
        }
        return html(template("admin_login.html").replace("<!--ERROR-->", ""));
    }

    @PostMapping("/admin/login")
    public ResponseEntity<String> login(@RequestParam(value = "password", defaultValue = "") String password,
                                        HttpServletRequest request) throws IOException {
        if (Config.isAdmin(request)) {
            return redirect("/admin");
        }
        String error;
        if (settings.adminPassword.isEmpty()) {
            error = "Admin password is not configured on the server.";
        } else if (MessageDigest.isEqual(
                password.getBytes(StandardCharsets.UTF_8),
                settings.adminPassword.getBytes(StandardCharsets.UTF_8))) {
            HttpSession old = request.getSession(false);
            if (old != null) {
                old.invalidate();
            }
            HttpSession session = request.getSession(true);
            session.setMaxInactiveInterval(2 * 60 * 60);
            session.setAttribute(Config.ADMIN_SESSION_KEY, true);
            return redirect("/admin");
        } else {
            error = "Invalid admin password.";
        }
        String block = "<div class=\"error\">" + HtmlUtils.htmlEscape(error) + "</div>";
        return html(template("admin_login.html").replace("<!--ERROR-->", block));
    }

    // ---------- admin logout ----------

    @RequestMapping(value = "/admin/logout", method = {RequestMethod.GET, RequestMethod.POST})
    public ResponseEntity<?> logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        String accept = request.getHeader(HttpHeaders.ACCEPT);
        boolean wantsJson = "POST".equalsIgnoreCase(request.getMethod())
                || (accept != null && accept.contains("json"));
        if (wantsJson) {
            return ResponseEntity.ok(Util.map("success", true, "message", "Logged out successfully."));
        }
        return redirect("/admin/login");
    }
}
